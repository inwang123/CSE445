﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace TryIt2
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            StemService.Service1Client stemService = new StemService.Service1Client();
            string s = inputBox.Text;
            TextBox2.Text = stemService.StemText(s);
           


        }

    }
}